// ============================================================
// CONFIGURAZIONE FIREBASE — da compilare con i TUOI dati
// ============================================================
// Dove trovarli:
// 1. Vai su https://console.firebase.google.com
// 2. Crea un progetto (gratuito, nessuna carta richiesta)
// 3. Nel progetto, vai su "Database Firestore" e creane uno
//    (scegli una regione europea, es. eur3)
// 4. Vai su Impostazioni progetto (icona ingranaggio) →
//    "Le tue app" → "Aggiungi app" → icona web "</>"
// 5. Copia qui sotto i valori che ti vengono mostrati
// ============================================================

window.FIREBASE_CONFIG = {
  apiKey: "INSERISCI_QUI",
  authDomain: "INSERISCI_QUI",
  projectId: "INSERISCI_QUI",
  storageBucket: "INSERISCI_QUI",
  messagingSenderId: "INSERISCI_QUI",
  appId: "INSERISCI_QUI"
};
